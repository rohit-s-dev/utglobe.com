<!-- <div class="feedback">
    -->
    <div class="feed-box">
    <div class="feedback_title">
        <h4>Feedback</h4>
    </div>
    <div class="row no-gutters">
        <div class="col-md-6">
            <div class="feedback_form">
                <form action="" method="post">
                    <div class="form-group">
                        <label for="name" >Name</label>
                        <input type="text" name="name" id="name" class="" placeholder=" Name">
                    </div>
                    <div class="form-group">
                        <label for="m_numb" >Mobile</label>
                        <input type="text" name="m_numb" id="m_numb" class="" placeholder="Mobile">
                    </div>
                    <div class="form-group">
                        <label for="email" >Email</label>
                        <input type="email" name="email" id="email" class="" placeholder="Email">
                    </div>
                    <button class="btn btn-primary" id="f_sub" type="submit">Submit  </button>
                </form>
            </div>
        </div>
        <div class="col-md-6">
          <div class="right_popup">
          <div class="p_right_box">
                <h3>Help us Improve our website</h3>
                <p>It will take your few seconds</p>
                <p>You will be redirected to a feedback page</p>
            </div>
            <span class="m_t"></span>
            <div class="offer_div">
                <p>Get <span>50%</span>Off</p>
            </div>
            <p class="text-center text-capitalize " style="color: #fff;">On Website Development</p>
            <div class="emo_box">
                <img src="assets/emoji2.png" width="60px" alt="">
            </div>
          </div>
        </div>
    </div>
    </div>
<!-- </div> -->