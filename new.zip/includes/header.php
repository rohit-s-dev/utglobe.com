<header>
			<div class="top-part__block">
				<div class="search__box-block">
					<div class="container">
					<input type="text" id="search" class="input-sm form-full" placeholder="Search Now">
					<a href="#!" class="search__close-btn"><i class="fa fa-times" aria-hidden="true"></i></a>
				</div>
				</div>
				<div class="container">
					<div class="row">
						<div class="col-sm-7">
							<p  style="color:#fff">
								Welcome to our corporate buisness
							</p>
						</div>
						<div class="col-sm-5">
							<div class="social-link__block text-right">
								<a href="#"><i class="fa fa-facebook" style="color:#fff"></i></a>
								<a href="#"><i class="fa fa-twitter" style="color:#fff"></i></a>
								<a href="#"><i class="fa fa-google-plus" style="color:#fff"></i></a>
								<a href="#"><i class="fa fa-linkedin" style="color:#fff"></i></a>
								 
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="middel-part__block">
				<div class="container">
					<div class="row">
						<div class="col-md-4">
							<div class="logo">
								<a href="index.php"><img src="assets/img/LOGO.png"  alt="Logo"/>  </a>
							</div>
						</div>
						<div class="col-md-8">
							<div class="top-info__block text-right">
								<ul>
									<li>
										<i class="fa fa-map-marker"></i>
										<p>
											Address <span>Rajiv Nagar, Road No.10 Patna Bihar</span>
										</p>
									</li>
									<li>
										<i class="fa fa-envelope"></i>
										<p>
											Email  <span> support@utglobe.com</span>
										</p>
									</li>
									<li>
										<i class="fa fa-phone"></i>
										<p>
											Phone No <span> 0612-2550527</span>
										</p>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>


			<div class="main_nav stricky-header__top">

				<nav class="navbar navbar-default navbar-sticky bootsnav">
					<div class="container">
						<!-- Start Header Navigation -->

						<div class="row">
							
							<div class="">
								<a href="index.php" target='_blank' class='n_logo navbar-brand' style='padding-top: 0;'>
									<img src="assets/images/LOGO-0.png" class='img-responsive' alt="Utesh Logo" width="100px">
								</a>
							</div>
							
							<div class="r_menu">
								<div class="navbar-header">
							<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
								<i class="fa fa-bars"></i>
							</button>

						</div>
						<!-- End Header Navigation -->
						<!-- Collect the nav links, forms, and other content for toggling -->

						<div class="collapse navbar-collapse" id="navbar-menu">
							<ul class="nav navbar-nav mobile-menu">
						<li> <a href="index.php">Home</a>  
						 
                  </li>
                  <li> <a href="aboutus.php">About us</a>   
                    
                  </li>
                  <li> <a href="javascript:avoid(0);">Our Services +</a> <span class="submenu-button"></span>
                   <ul class="dropdown-menu">
									<li class='sub-dropdown-menu' >
										<a href="javascript:avoid(0);">Information Technologies +
										</a> 
										<span class="submenu-button"></span>
						                <ul class=' dropdown-menu'>
                                          <li> <a href="webdevelopement.php">web Developement</a> </li>
                                          <li> <a href="softwaredevelopement.php">Software Developement</a> </li>
                                          <li> <a href="digitalmarketing.php">Digital Marketing</a> </li>
                                          <li> <a href="seo.php">SEO Services</a> </li>
                                          <li> <a href="mobileapp.php"> Mobile App</a> </li>
                                           <li> <a href="graphics.php">Logo Design/Graphics</a> </li>
                                            <li> <a href="webhosting.php"> Web Hosting</a> </li>
                                             <li> <a href="domainreg.php"> Domain Registration</a> </li>
                                        </ul>
									</li>

									<li>
										<a href="http://legalustaad.com/">Legal Services</a>
									</li>
                                    <li>
										<a href="https://bookyourproduct.com/byp2/">E-Commerce</a>
									</li>
                                    <li>
										<a href="http://uteshindustries.com/">Interior</a>
									</li>
									<li>
										<a href="http://uteshindustries.com/">Manufacturing</a>
									</li>
                                    <li>
										<a href="http://khabariyanews.com/">Khabariya News</a>
									</li>
									<li>
										<a href="certification.php">Certification</a>
									</li>

									<li>
										<a href="businessform.php">Service/Support</a>
									</li>
									 

								</ul>
                  </li>
                  <li> <a href="portfolio.php">Portfolio</a>
                   
                  </li>
               
               
                   
                 
				  <li><a class="custom_btn__block" href="contactus.php">Contact Us</a></li>
                   <li><a class="custom_btn__block" href="#" style=" background:#f6bb18 none repeat scroll 0 0">Login</a></li>
                </ul>
                </div>
							</div>
						</div>

						
						<!--navbar-collapse -->


					</div>
				</nav>



			</div>
		</header>