<footer id="footer">
			<div id="footer-widgets" class="container style-1">
				<div class="row">
					<div class="col-md-4">
						<div class="widget widget_text">
							<h2 class="widget-title"><span>ABOUT US</span></h2>
							<div class="textwidget">
								<a href="index.php" class="footer-logo"> <img src="assets/images/LOGO-0.png" /> </a>
								<p>
								Utesh Technologies is a Design and Animation Studio that specialize in Graphics Designing, Website Designing & Development, Corporate identity . We offer the industry's broadest and most comprehensice range of solutions.. © 2014 Utesh Technologies Passionate People. Creative Thinking
								</p>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="widget widget_links">
							<h2 class="widget-title"><span>COMPANY LINKS</span></h2>
							<ul class="wprt-links clearfix col2">
                                 <li>
									<a href="index.php">Home</a>
								</li>
                                <li>
									<a href="#">IT Services</a>
								</li>
								<li>
									<a href="aboutus.php">About Us</a>
								</li>
                                <li>
									<a href="http://legalustaad.com//" target="_blank">Legal Services</a>
								</li>
								<li>
									<a href="#">Services</a>
								</li>
                                	<li>
									<a href="http://uteshindustries.com"target="_blank">Manufacturing</a>
								</li>
								
								<li>
									<a href="https://wabsus.com/" target="_blank">Interior</a>
								</li>
								<li>
									<a href="contactus.php">Contact Us</a>
								</li>
								 
								<li>
									<a href="#">Cerification/HR</a>
								</li>
								<li>
									<a href="http://bookyourproduct.com/" target="_blank">E-Commerce</a>
								</li>
								<li>
									<a href="http://khabariyanews.com/" target="_blank">News Portal</a>
								</li>
							</ul>
						</div>
					</div>
					<div class="col-md-4">
						<div class="widget widget_information">
							<h2 class="widget-title"><span>CONTACT INFO</span></h2>
							<ul>
								<li class="address clearfix">
									<span class="hl">Address:</span>
									<span class="text">Above Devraj Sweets,Rajiv Nagar Road No-10,Pin-800024 Patna</span>
								</li>
								<li class="phone clearfix">
									<span class="hl">Phone:</span>
									<span class="text">0612-2550527</span>
								</li>
								<li class="email clearfix">
									<span class="hl">E-mail:</span>
									<span class="text">support@utglobe.com</span>
								</li>
							</ul>
						</div>
						<div class="widget widget_socials">
							<div class="socials">
								<a href=><i class="fa fa-twitter"></i></a>
								<a target="_blank" href=www.facebook.com/UTESHTECHNOLOGIES"><i class="fa fa-facebook"></i></a>
								<a target="_blank" href="#"><i class="fa fa-google-plus"></i></a>
								<a target="_blank" href="#"><i class="fa fa-pinterest"></i></a>
								<a target="_blank" href="#"><i class="fa fa-dribbble"></i></a>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div id="bottom" class="clearfix style-1">
				<div id="bottom-bar-inner" class="wprt-container">
					<div class="bottom-bar-inner-wrap">
						<div class="bottom-bar-content">
							<div id="copyright"><p>© 2014  UTESH Technologies . All rights reserved</p>
							
							</div>
							<!-- /#copyright -->
						</div>
						<!-- /.bottom-bar-content -->
						<div class="bottom-bar-menu">
							<ul class="bottom-nav">
								<!-- <li>
									<a href="#">HISTORY</a>
								</li> -->
								<li>
									<a href="#">FAQ</a>
								</li>
								<li>
									<a href="#">EVENTS</a>
								</li>
							</ul>
						</div>
						<!-- /.bottom-bar-menu -->
					</div>
				</div>
			</div>
		</footer>