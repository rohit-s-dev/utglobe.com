<?php
if (isset($_POST['name'])) {
    echo "<script>
    alert('Thank You');
    </script>";
}