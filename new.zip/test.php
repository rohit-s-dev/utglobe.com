<?php
$to = 'test@utglobe.com';
$sub = 'Free Consultation Mail';
$headers = "utglobe.com";
$n = "utglobe.com";
mail($to, $sub, $n);